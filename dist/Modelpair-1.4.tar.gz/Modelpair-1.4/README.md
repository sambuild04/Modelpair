# neuralpackage
# Modelpair

This is a Python package that is designed to compare different machine learning model performance on a dataset

### Current Progress
* Implemented data preprocessing methods for Excel csv file(in certain format)
* Implemented decision tree, KNN and neural network algorithms
* Implemented accuracy comparison methods

